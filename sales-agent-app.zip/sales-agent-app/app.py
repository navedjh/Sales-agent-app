"""
app.py
FastAPI web app for the Conversational Sales Agent.

Run:
    uvicorn app:app --reload

Open:
    http://127.0.0.1:8000
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List
from uuid import uuid4

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from agent import SalesAgent
from utils import ensure_csv, read_leads

app = FastAPI(title="Conversational Sales Agent", version="1.0.0")

FOLLOWUP_MESSAGES: Dict[str, List[str]] = {}


async def send_followup(lead_id: str, text: str) -> None:
    FOLLOWUP_MESSAGES.setdefault(lead_id, []).append(text)


agent = SalesAgent(followup_delay=10, followup_sender=send_followup)
ensure_csv()

app.mount("/static", StaticFiles(directory="static"), name="static")


class ChatRequest(BaseModel):
    lead_id: str = Field(default_factory=lambda: f"lead_{uuid4().hex[:8]}")
    message: str


class ChatResponse(BaseModel):
    lead_id: str
    reply: str
    status: str
    lead_saved: bool = False
    data: Dict[str, str] = {}


@app.get("/")
async def home():
    return FileResponse(Path("static") / "index.html")


@app.post("/api/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    reply = await agent.process_message(request.lead_id, request.message)
    return ChatResponse(
        lead_id=request.lead_id,
        reply=reply.text,
        status=reply.status,
        lead_saved=reply.lead_saved,
        data=reply.data,
    )


@app.get("/api/followups/{lead_id}")
async def get_followups(lead_id: str):
    messages = FOLLOWUP_MESSAGES.pop(lead_id, [])
    return {"lead_id": lead_id, "messages": messages}


@app.get("/api/leads")
async def leads():
    return {"leads": read_leads()}


@app.get("/api/sessions")
async def sessions():
    return {"sessions": agent.get_active_sessions()}
