"""
agent.py
Conversational Sales Agent built to work with Google ADK-style Agent objects,
plus a safe local fallback for normal Python/FastAPI testing.

Flow:
1. New lead starts conversation.
2. Agent asks for consent before collecting information.
3. Agent collects age, country, and interested product/service step-by-step.
4. Agent supports independent sessions by lead/session ID.
5. Agent schedules a follow-up message after inactivity.
6. Completed or rejected leads are saved to leads.csv.
"""

from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, Optional

from utils import update_csv

try:
    # Official ADK import. The app can still run locally if google-adk is not installed.
    from google.adk.agents import Agent as ADKAgent
except Exception:  # pragma: no cover
    class ADKAgent:  # type: ignore
        def __init__(self, name: str = "sales_agent", **kwargs: Any) -> None:
            self.name = name


QUESTIONS = [
    ("age", "What is your age?"),
    ("country", "Which country are you from?"),
    ("interest", "What product or service are you interested in?")
]

CONSENT_QUESTION = (
    "Hey! Thank you for your interest. Before we continue, may I collect a few basic "
    "details to help our sales team recommend the right product or service?"
)

FOLLOW_UP_TEXT = (
    "Just checking in to see if you're still interested. Reply whenever you're ready to continue."
)


@dataclass
class LeadState:
    step: int = 0
    consent_given: bool = False
    responses: Dict[str, str] = field(default_factory=dict)
    followup_task: Optional[asyncio.Task] = None


@dataclass
class AgentReply:
    text: str
    status: str = "active"
    lead_saved: bool = False
    data: Dict[str, str] = field(default_factory=dict)


class SalesAgent(ADKAgent):
    """
    Deterministic sales qualification agent.

    It intentionally avoids collecting information before consent. Session state is keyed
    by `session_id`, so many leads can interact concurrently without mixing data.
    """

    def __init__(
        self,
        followup_delay: int = 10,
        followup_sender: Optional[Callable[[str, str], Awaitable[None]]] = None,
    ) -> None:
        super().__init__(name="sales_agent")
        self.followup_delay = followup_delay
        self.followup_sender = followup_sender
        self._context: Dict[str, LeadState] = {}

    def _normalise(self, text: str) -> str:
        return text.strip().lower()

    def _is_yes(self, text: str) -> bool:
        value = self._normalise(text)
        yes_words = {"yes", "y", "ok", "okay", "sure", "agree", "i agree", "continue", "go ahead"}
        return value in yes_words or any(word in value.split() for word in ["yes", "agree", "sure"])

    def _is_no(self, text: str) -> bool:
        value = self._normalise(text)
        no_words = {"no", "n", "nope", "not now", "don't", "do not", "stop"}
        return value in no_words or "no" in value.split() or "stop" in value.split()

    def _validate_age(self, text: str) -> Optional[str]:
        match = re.search(r"\b(\d{1,3})\b", text.strip())
        if not match:
            return "Please enter your age as a number, for example: 25."
        age = int(match.group(1))
        if age < 13 or age > 100:
            return "Please enter a valid age between 13 and 100."
        return None

    def _validate_text(self, text: str, field_name: str) -> Optional[str]:
        if len(text.strip()) < 2:
            return f"Please enter a valid {field_name}."
        return None

    def _current_question(self, state: LeadState) -> str:
        if state.step < len(QUESTIONS):
            return QUESTIONS[state.step][1]
        return ""

    async def handle_message(self, session: Any, message: Any) -> None:
        """
        ADK-style handler. It accepts a session object with `session_id` and `send_text`.
        """
        lead_id = getattr(session, "session_id", getattr(session, "id", "unknown_session"))
        text = getattr(message, "text", str(message))
        reply = await self.process_message(lead_id, text)
        await session.send_text(reply.text)

    async def process_message(self, lead_id: str, text: str) -> AgentReply:
        """
        Framework-neutral API used by FastAPI, tests, and simulations.
        """
        text = text.strip()
        if not text:
            return AgentReply("Please type a message so I can help you.")

        self._cancel_followup(lead_id)

        if lead_id not in self._context:
            self._context[lead_id] = LeadState()
            await self._schedule_followup(lead_id)
            return AgentReply(CONSENT_QUESTION, status="awaiting_consent")

        state = self._context[lead_id]

        if not state.consent_given:
            if self._is_yes(text):
                state.consent_given = True
                state.step = 0
                await self._schedule_followup(lead_id)
                return AgentReply(QUESTIONS[0][1], status="collecting_age")

            if self._is_no(text):
                update_csv(lead_id, {}, "consent_declined")
                self._context.pop(lead_id, None)
                return AgentReply(
                    "No problem. I will not collect your details. Have a great day!",
                    status="consent_declined",
                    lead_saved=True,
                )

            await self._schedule_followup(lead_id)
            return AgentReply(
                "Please reply with yes if you consent, or no if you do not want to continue.",
                status="awaiting_consent",
            )

        field, _question = QUESTIONS[state.step]
        validation_error = (
            self._validate_age(text) if field == "age" else self._validate_text(text, field)
        )
        if validation_error:
            await self._schedule_followup(lead_id)
            return AgentReply(validation_error, status=f"collecting_{field}")

        state.responses[field] = text

        if state.step < len(QUESTIONS) - 1:
            state.step += 1
            await self._schedule_followup(lead_id)
            next_field, next_question = QUESTIONS[state.step]
            return AgentReply(next_question, status=f"collecting_{next_field}")

        data = {
            "age": state.responses.get("age", ""),
            "country": state.responses.get("country", ""),
            "interest": state.responses.get("interest", ""),
        }
        update_csv(lead_id, data, "secured")
        self._context.pop(lead_id, None)
        return AgentReply(
            "Thank you! Your information has been recorded. Our sales specialist will contact you shortly.",
            status="secured",
            lead_saved=True,
            data=data,
        )

    def _cancel_followup(self, lead_id: str) -> None:
        state = self._context.get(lead_id)
        if state and state.followup_task and not state.followup_task.done():
            state.followup_task.cancel()
            state.followup_task = None

    async def _schedule_followup(self, lead_id: str) -> None:
        if self.followup_delay <= 0 or self.followup_sender is None:
            return
        state = self._context.get(lead_id)
        if state is None:
            return
        state.followup_task = asyncio.create_task(self._followup_after_delay(lead_id))

    async def _followup_after_delay(self, lead_id: str) -> None:
        try:
            await asyncio.sleep(self.followup_delay)
            if lead_id in self._context and self.followup_sender:
                await self.followup_sender(lead_id, FOLLOW_UP_TEXT)
        except asyncio.CancelledError:
            pass

    def get_active_sessions(self) -> Dict[str, Dict[str, Any]]:
        return {
            lead_id: {
                "step": state.step,
                "consent_given": state.consent_given,
                "responses": dict(state.responses),
            }
            for lead_id, state in self._context.items()
        }
