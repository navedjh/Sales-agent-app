"""
utils.py
Thread-safe CSV helper functions for the Sales Agent app.
"""

from __future__ import annotations

import csv
import os
import threading
from pathlib import Path
from typing import Dict, List

CSV_FILE = Path("leads.csv")
FIELDS = ["lead_id", "age", "country", "interest", "status"]
_LOCK = threading.Lock()


def ensure_csv(file_path: Path = CSV_FILE) -> None:
    if not file_path.exists():
        with file_path.open("w", newline="", encoding="utf-8") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=FIELDS)
            writer.writeheader()


def read_leads(file_path: Path = CSV_FILE) -> List[Dict[str, str]]:
    ensure_csv(file_path)
    with _LOCK:
        with file_path.open(newline="", encoding="utf-8") as csvfile:
            return list(csv.DictReader(csvfile))


def update_csv(lead_id: str, data: Dict[str, str], status: str, file_path: Path = CSV_FILE) -> None:
    """
    Create or update a lead row.
    """
    ensure_csv(file_path)

    with _LOCK:
        rows: List[Dict[str, str]] = []
        found = False

        with file_path.open(newline="", encoding="utf-8") as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                if row.get("lead_id") == lead_id:
                    for key in ["age", "country", "interest"]:
                        if key in data:
                            row[key] = data.get(key, "")
                    row["status"] = status
                    found = True
                rows.append(row)

        if not found:
            rows.append({
                "lead_id": lead_id,
                "age": data.get("age", ""),
                "country": data.get("country", ""),
                "interest": data.get("interest", ""),
                "status": status,
            })

        tmp_path = file_path.with_suffix(".tmp")
        with tmp_path.open("w", newline="", encoding="utf-8") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(rows)
        os.replace(tmp_path, file_path)
