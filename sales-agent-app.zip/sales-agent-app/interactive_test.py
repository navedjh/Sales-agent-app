import asyncio
import aioconsole
from agent import SalesAgent


async def main():
    lead_id = "manual_lead"

    async def followup_sender(session_id: str, text: str):
        print(f"\nAgent Follow-up: {text}")

    agent = SalesAgent(followup_delay=10, followup_sender=followup_sender)

    print("Sales Agent is ready.")
    print("Type your messages. Type 'exit' to quit.")
    print("Tip: wait 10 seconds after an agent question to see the follow-up reminder.\n")

    while True:
        user_input = await aioconsole.ainput("You: ")
        if user_input.strip().lower() == "exit":
            break

        reply = await agent.process_message(lead_id, user_input)
        print(f"Agent: {reply.text}")


if __name__ == "__main__":
    asyncio.run(main())
