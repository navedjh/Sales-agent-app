import asyncio
from agent import SalesAgent


async def simulate_lead(agent: SalesAgent, lead_id: str, messages: list[str]):
    print(f"\n--- Simulating {lead_id} ---")
    for msg in messages:
        print(f"{lead_id}: {msg}")
        reply = await agent.process_message(lead_id, msg)
        print(f"Agent: {reply.text}")
        await asyncio.sleep(0.2)


async def main():
    async def followup_sender(lead_id: str, text: str):
        print(f"FOLLOW-UP to {lead_id}: {text}")

    agent = SalesAgent(followup_delay=10, followup_sender=followup_sender)

    await asyncio.gather(
        simulate_lead(agent, "lead_india_001", ["Hi", "yes", "25", "India", "Premium Travel Package"]),
        simulate_lead(agent, "lead_uae_002", ["Hello", "yes", "34", "UAE", "Cloud CRM"]),
        simulate_lead(agent, "lead_no_003", ["Interested", "no"]),
    )

    print("\nSimulation complete. Check leads.csv")


if __name__ == "__main__":
    asyncio.run(main())
